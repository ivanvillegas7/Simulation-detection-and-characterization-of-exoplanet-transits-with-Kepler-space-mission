Files which were not included in the archive (either unavailable or you lack privileges):
